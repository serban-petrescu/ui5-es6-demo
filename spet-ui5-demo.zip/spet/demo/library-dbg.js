sap.ui.define(["sap/ui/Global", "jquery.sap.global"], function (_Global, _jquerySap) {
  "use strict";

  var exports = {};
  Object.defineProperty(exports, "__esModule", {
    value: true
  });

  var _Global2 = _interopRequireDefault(_Global);

  var _jquerySap2 = _interopRequireDefault(_jquerySap);

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }

  /**
   * Demo UI5 library which uses ES6 syntax.
   * @namespace
   * @name spet.demo
   * @version 0.0.1
   * @public
   */
  var oLibrary = _Global2.default.getCore().initLibrary({
    name: "spet.demo",
    version: "0.0.1",
    dependencies: ["sap.ui.core"],
    types: [],
    interfaces: [],
    controls: [],
    elements: [],
    noLibraryCSS: true
  }) || _jquerySap2.default.sap.getObject("spet.demo");

  // function definitions "borrowed" from https://medium.com/@adambene/currying-in-javascript-es6-540d2ad09400

  /**
   * Transforms a given (bi)function in curry-enabled function.
   * @method spet.demo.curry
   * @param {function} f The function to be curried.
   * @returns {function} The curried function.
   */
  oLibrary.curry = function (f) {
    return function (a) {
      return function (b) {
        return f(a, b);
      };
    };
  };

  /**
   * Transforms a given curried (bi)function in a regular function.
   * @method spet.demo.uncurry
   * @param {function} f The function to be uncurried.
   * @returns {function} The resulting regular function.
   */
  oLibrary.uncurry = function (f) {
    return function (a, b) {
      return f(a)(b);
    };
  };

  /**
   * Does a partial application on a function (by supplying its first parameter).
   * @method spet.demo.papply
   * @param {function} f The function to be applied.
   * @param {any} 	 a The value for the first parameter of the function.
   * @returns {function} The resulting function (which has one less parameter).
   */
  oLibrary.papply = function (f, a) {
    return function (b) {
      return f(a, b);
    };
  };

  exports.default = oLibrary;
  return exports.default;
});
//# sourceMappingURL=library.js.map
