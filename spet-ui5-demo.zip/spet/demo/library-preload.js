jQuery.sap.registerPreloadedModules({
	"version": "2.0",
	"name": "spet.demo.library-preload",
	"modules": {
		"spet/demo/library.js": "sap.ui.define([\"sap/ui/Global\",\"jquery.sap.global\"],function(e,n){\"use strict\";function r(e){return e&&e.__esModule?e:{default:e}}var t={};Object.defineProperty(t,\"__esModule\",{value:!0});var u=r(e),i=r(n),o=u.default.getCore().initLibrary({name:\"spet.demo\",version:\"0.0.1\",dependencies:[\"sap.ui.core\"],types:[],interfaces:[],controls:[],elements:[],noLibraryCSS:!0})||i.default.sap.getObject(\"spet.demo\");return o.curry=function(e){return function(n){return function(r){return e(n,r)}}},o.uncurry=function(e){return function(n,r){return e(n)(r)}},o.papply=function(e,n){return function(r){return e(n,r)}},t.default=o,t.default});"
	}
});