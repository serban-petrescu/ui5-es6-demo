# UI5 ES6 Demo Library [![Build Status](https://travis-ci.org/serban-petrescu/ui5-es6-demo.svg?branch=master)](https://travis-ci.org/serban-petrescu/ui5-es6-demo)
Repository which shows how to enable the usage of ES6 syntax when building UI5 libraries.

The latest version of the library cab be downloaded from here: [ui5-demo.zip](https://serban-petrescu.github.io/ui5-es6-demo/spet-ui5-demo.zip).

You can find the documentation here: [JsDoc](https://serban-petrescu.github.io/ui5-es6-demo/jsdoc/), [Presentation](https://serban-petrescu.github.io/ui5-es6-demo/docs/presentation/).
